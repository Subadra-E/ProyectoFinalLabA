/* 
 * LA03StackingAction.cc: Implementación para la clase
 * LA03StackingAction.
 * 
 * Archivo de ejemplo de Geant4 para la unidad 3
 * del curso de Laboratorio Avanzado ECFM-USAC
 * 
 * Héctor Pérez
 * abril 2021
 * 
 * Basado en el ejemplo B1 de Geant4.10.06.p03
 */

#include "LA01StackingAction.hh"
#include "LA01EventAction.hh"
#include "LA01DetectorConstruction.hh"

#include "G4VProcess.hh"

#include "G4ParticleDefinition.hh"
#include "G4ParticleTypes.hh"
#include "G4Track.hh"
#include "G4ios.hh"
#include "G4RunManager.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......


LA01StackingAction::LA01StackingAction(LA01EventAction* eventAction)
  : G4UserStackingAction(),
  EventAction(eventAction)
{}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

LA01StackingAction::~LA01StackingAction()
{}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4ClassificationOfNewTrack
LA01StackingAction::ClassifyNewTrack(const G4Track * aTrack)
{
    if( aTrack->GetParentID() > 0 ) // No se debe de considerar al ID 0 en la cuenta
    {
        if(aTrack->GetVolume()->GetName()=="Target1"){ //para los rayos que llegan al cloro
          if(aTrack->GetParticleDefinition()->GetParticleName()== "e-"){// condicion que cuenta 
          EventAction->AddNcont(1.0);  // aumenta el contador cada vez que se generan electrones en el cloro                                 // cuando se generan electrones
      }                                // sin sobrecontar
      //se aniquila las particulas para contarlas solo una vez
       return fKill;

      }

        
    } 
       
  return fUrgent;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void LA01StackingAction::NewStage()
{

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void LA01StackingAction::PrepareNewEvent()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

