/* 
 * LA01DetectorConstruction.cc: Implementación para la clase
 * LA01DetectorConstrucion.
 * 
 * Archivo de ejemplo de Geant4 para la unidad 3
 * del curso de Laboratorio Avanzado ECFM-USAC
 * 
 * Héctor Pérez
 * abril 2021
 *
 * Modificaciones: Subadra Echeverria
 * Mayo 2021
 * 
 * Basado en el ejemplo B1 de Geant4.10.06.p03
 */

#include "LA01DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

LA01DetectorConstruction::LA01DetectorConstruction()
: G4VUserDetectorConstruction(),
  fScoringVolume(0)
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

LA01DetectorConstruction::~LA01DetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* LA01DetectorConstruction::Construct()
{  
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();
   
  // Option to switch on/off checking of volumes overlaps
  //
  G4bool checkOverlaps = true;

  //     
  // World
  //
  G4double world_sizeX = 250*mm;
  G4double world_sizeY = 250*mm; 
  G4double world_sizeZ = 250*mm;
  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
  
  G4Box* solidWorld =    
    new G4Box("World",                       //its name
       0.5*world_sizeX, 0.5*world_sizeY, 0.5*world_sizeZ);     //its size
      
  G4LogicalVolume* logicWorld =                         
    new G4LogicalVolume(solidWorld,          //its solid
                        world_mat,           //its material
                        "World");            //its name
                                   
  G4VPhysicalVolume* physWorld = 
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(),       //at (0,0,0)
                      logicWorld,            //its logical volume
                      "World",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking
                     
 
 
  //     
  // Target0 (padre) cilindro de acero Inoxidable
  //  
  G4ThreeVector pos0 = G4ThreeVector(0, 0, 0);
        
  G4double target0_RMin = 0*mm;
  G4double target0_RMax = 12.5*mm;
  G4double target0_sizeZ = 75*mm;
  G4double target0_SPhi = 0;
  G4double target0_DPhi = twopi;

  G4Material* target_mat0 = nist->FindOrBuildMaterial("G4_STAINLESS-STEEL"); //Cilindro padre de acero inoxidable

  G4Tubs* solidTarget0 =    
    new G4Tubs("Target0",                       //its name
      target0_RMin, target0_RMax, 0.5*target0_sizeZ, target0_SPhi, target0_DPhi);
                      
  G4LogicalVolume* logicTarget0 =                         
    new G4LogicalVolume(solidTarget0,         //its solid
                        target_mat0,          //its material
                        "Target0");           //its name
               
  new G4PVPlacement(0,                       //no rotation
                    pos0,                    //at position
                    logicTarget0,             //its logical volume
                    "Target0",                //its name
                    logicWorld,                //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking

  
//     
  // Target1 (hijo) cilindro de Cloro
  //  
  G4ThreeVector pos1 = G4ThreeVector(0, 0, 3.95*mm);//posición respecto al padre
                                                    //Target0        
  G4double target1_RMin = 0*mm;
  G4double target1_RMax = 4.5*mm;
  G4double target1_sizeZ = 66.9*mm;
  G4double target1_SPhi = 0;
  G4double target1_DPhi = twopi;

  G4Material* target_mat1 = nist->FindOrBuildMaterial("G4_Cl"); //Cilindro hijo de Cloro

  G4Tubs* solidTarget1 =    
    new G4Tubs("Target1",                       //its name
      target1_RMin, target1_RMax, 0.5*target1_sizeZ, target1_SPhi, target1_DPhi);
                      
  G4LogicalVolume* logicTarget1 =                         
    new G4LogicalVolume(solidTarget1,         //its solid
                        target_mat1,          //its material
                        "Target1");           //its name
               
  new G4PVPlacement(0,                       //no rotation
                    pos1,                    //at position
                    logicTarget1,             //its logical volume
                    "Target1",                //its name
                    logicTarget0,                //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking

  



                
  // Set Target as scoring volume
  //
  fScoringVolume = logicTarget1; //el objetivo es el volumen de cloro

  //
  //always return the physical World
  //
  return physWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
