/* 
 * LA01PrimaryGeneratorAction.cc: Implementación para la clase
 * LA01PrimaryGeneratorAction.
 * 
 * Archivo de ejemplo de Geant4 para la unidad 3
 * del curso de Laboratorio Avanzado ECFM-USAC
 * 
 * Héctor Pérez
 * abril 2021
 * 
 * Basado en el ejemplo B1 de Geant4.10.06.p03
 */

#include "LA01PrimaryGeneratorAction.hh"

#include "G4LogicalVolumeStore.hh"
#include "G4LogicalVolume.hh"
#include "G4Box.hh"
#include "G4RunManager.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4PhysicalConstants.hh"

#include <cmath>

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

LA01PrimaryGeneratorAction::LA01PrimaryGeneratorAction()
: G4VUserPrimaryGeneratorAction(),
  fParticleGun(0)
{
  G4int n_particle = 1;
  fParticleGun  = new G4ParticleGun(n_particle);

  // default particle kinematic
  G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
  G4String particleName;
  G4ParticleDefinition* particle
    = particleTable->FindParticle(particleName="gamma");
  fParticleGun->SetParticleDefinition(particle);
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0.,0.,-1.));
  fParticleGun->SetParticleEnergy(6.*MeV);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

LA01PrimaryGeneratorAction::~LA01PrimaryGeneratorAction()
{
  delete fParticleGun;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void LA01PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
  //this function is called at the begining of ecah event
  // Acá es donde se indica que el punto de lanzamiento estará sobre 
  // un cilindro (moneda) de grosor de 1mm y radio de 15 mm
  G4double radiof = G4UniformRand()*15*mm; //radio aleatorio de lanzamiento
  G4double thetaf = G4UniformRand()*twopi; //angulo aleatorio de lanzamiento
  G4double zf = G4UniformRand()*1.*mm;  //posicion en z aleatoria de lanzamiento
  
  G4double x0 = radiof*std::cos(thetaf); //Relacion con las coordenadas cilindricas
  G4double y0 = radiof*std::sin(thetaf);
  G4double z0 = zf+(87.5*mm); //posicion en z considerando los 50mm entre la fuente y el detector
                              //más 37.5 mm del largo del cilindro de acero
  // posicion de lanzamiento inicial de los rayos
  fParticleGun->SetParticlePosition(G4ThreeVector(x0,y0,z0));

  /* Dirección aleatoria para las particulas lanzadas */
  /* sobre una esfera de radio 1*/
  G4double theta = twopi * G4UniformRand();
  G4double phi = pi * G4UniformRand();

  /*cambio a coordenadas esfericas*/
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector( std::sin(theta)*std::cos(phi), std::sin(theta)*std::sin(phi), std::cos(theta)));

  fParticleGun->GeneratePrimaryVertex(anEvent);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

